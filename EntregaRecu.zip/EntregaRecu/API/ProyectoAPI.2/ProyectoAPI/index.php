<?php
header("Access-Control-Allow-Origin: *");
require_once 'response.php';
require_once 'Libro.php';

$libro = new Libro();

switch ($_SERVER['REQUEST_METHOD']) {
        //Método get
    case 'GET':
        $params = $_GET;
        $libros = $libro->get($params);

        $response = array(
            'result' => 'ok',
            'libros' => $libros
        );
        Response::result(200, $response);
        break;
}
