<?php
//Importamos la clase Response y la clase Database
require_once 'response.php';
require_once 'database.php';

class Libro extends Database
{
	//indicamos los parámetros válidos para las peticiones get mediante un array
	private $allowedConditions_get = array('id', 'autor', 'genero', 'pagina');

	/**
	 * Procesa una solicitud GET para obtener recursos, aplicando filtros permitidos si se especifican.
	 *
	 * @param array $params Un array asociativo que contiene los parámetros de la solicitud GET.
	 *                      Los parámetros pueden incluir condiciones de filtrado para los recursos.
	 * @return array Un array de recursos que coinciden con los criterios de filtrado, si se especifican.
	 */
	public function get($params)
	{
		//Recorremos los parámetros get
		foreach ($params as $key => $param) {
			//si los parámetros no están permitidos...
			if (!in_array($key, $this->allowedConditions_get)) {
				//eliminamos los parámetros
				unset($params[$key]);
				//creamos el array de error
				$response = array(
					'result' => 'error',
					'details' => 'Error en la solicitud'
				);
				//devolvemos la petición de error convertida a json
				Response::result(400, $response);
				exit;
			}
		}
		//llamamos 
		$datos = parent::obtenerLibros($params);

		return $datos;
	}
}
