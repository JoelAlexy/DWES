<?php
class Libreria
{
    /**
     * Lee los datos de un archivo XML y los convierte en un arreglo de libros.
     *
     * @return array Un arreglo de libros, donde cada libro está representado como un array asociativo.
     */
    private function cargarDatosDesdeXML()
    {
        $archivoXML = '../xml/books.xml';
        $datosXML = simplexml_load_file($archivoXML);
        $coleccionLibros = [];

        foreach ($datosXML->book as $libro) {
            $coleccionLibros[] = [
                'codigo' => (string)$libro['id'],
                'escritor' => (string)$libro->author,
                'titulo' => (string)$libro->title,
                'categoria' => (string)$libro->genre,
                'precio' => (int)$libro->price,
                'publicacion' => (int)$libro->publish_date,
                'resumen' => (string)$libro->description
            ];
        }
        return $coleccionLibros;
    }

    /**
     * Obtiene una lista de libros filtrada según los parámetros especificados.
     *
     * @param array $filtros Un array asociativo con los filtros de búsqueda opcionales.
     *                        Los filtros pueden incluir cualquier campo del libro, como título, autor, etc.
     *                        Además, puede incluir el filtro 'pagina' para paginar los resultados.
     * @return array Una matriz de libros que coinciden con los criterios de filtrado.
     */
    public function obtenerListaLibros($filtros = [])
    {
        $coleccionLibros = $this->cargarDatosDesdeXML();
        if (!is_array($filtros)) {
            return $coleccionLibros;
        } else {
            foreach ($filtros as $campo => $valor) {
                if ($campo !== 'pagina') {
                    $coleccionLibros = array_filter($coleccionLibros, function ($libro) use ($campo, $valor) {
                        return stripos($libro[$campo], $valor) !== false;
                    });
                } elseif (isset($filtros['pagina'])) {
                    $pagina = (int)$filtros['pagina'];
                    $tamanioPagina = 3; // Puedes cambiarlo según sea necesario
                    $librosPaginados = array_slice($coleccionLibros, $pagina * $tamanioPagina, $tamanioPagina);
                    $coleccionLibros = $librosPaginados;
                }
            }

            return array_values($coleccionLibros);
        }
    }
}
