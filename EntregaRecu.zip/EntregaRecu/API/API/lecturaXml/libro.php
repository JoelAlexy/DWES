<?php
require_once 'Respuesta.php';
include_once('./DDBB.php');

class Libro extends Libreria
{
    private $filtrosPermitidos_get = array('id', 'autor', 'genero', 'pagina');

    /**
     * Procesa una solicitud GET para obtener recursos, aplicando filtros permitidos si se especifican.
     *
     * @param array $filtros Un array asociativo que contiene los filtros de la solicitud GET.
     *                       Los filtros pueden incluir condiciones de filtrado para los recursos.
     * @return array Un array de recursos que coinciden con los criterios de filtrado, si se especifican.
     */
    public function obtenerLibrosConFiltros($filtros)
    {
        foreach ($filtros as $clave => $filtro) {
            if (!in_array($clave, $this->filtrosPermitidos_get)) {
                unset($filtros[$clave]);
                $respuesta = array(
                    'result' => 'error',
                    'detalles' => 'Error en la solicitud'
                );
                RespuestaServicio::enviarRespuesta(400, $respuesta);
                exit;
            }
        }

        $datosLibros = parent::obtenerListaLibros($filtros);
        return $datosLibros;
    }
}
?>
