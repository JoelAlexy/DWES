<?php
include_once 'Respuesta.php';
include_once 'libro.php';

$libro = new Libro();

if (($_SERVER['REQUEST_METHOD'])) {
    //Método get
    if ('GET')
    $libros = $libro->obtenerLibrosConFiltros($_GET);

    $resultado = array(
        'result' => 'ok',
        'libros' => $libros
    );
    RespuestaServicio::enviarRespuesta(200, $resultado);
}
