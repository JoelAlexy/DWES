/*
Aquí se define una clase UserController que actúa como un intermediario entre el modelo y la vista.
Al instanciar un UserController, se crea una instancia del modelo (Model) y de la vista (View).
Define un método fetchData que toma un tipo y un valor como argumentos.
Llama al método fetchData del modelo para obtener los datos y luego llama al método displayData de la vista para mostrar los datos obtenidos.
Si hay un error, llama al método displayError de la vista para manejar el error.
*/
import Model from "./Model.js";
import View from "./View.js";

export default class UserController {
    constructor() {
        this.model = new Model();
        this.view = new View();
    }

    async fetchData(tipo, valor) {
        try {
            const data = await this.model.fetchData(tipo, valor);
            this.view.displayData(data);
        } catch (error) {
            this.view.displayError(error);
        }
    }   
}
