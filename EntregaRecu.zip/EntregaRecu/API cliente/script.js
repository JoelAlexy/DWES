import Controller from "./Controller.js";

const ControllerPrincipal = new Controller();
const selectValor = document.getElementById("tipo");
const textoValor = document.getElementById("valor");
const boton = document.getElementById("enviarSolicitud");

boton.addEventListener("click", () => {
    ControllerPrincipal.fetchData(selectValor.value, textoValor.value);
    //selectValor.value = "";
    //textoValor.value = "";
});
