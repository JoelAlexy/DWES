/*
Este archivo define una clase Model que se encarga de realizar la solicitud HTTP para obtener datos de la API.
Utiliza axios para realizar la solicitud GET a la URL especificada con el tipo y valor dados.
Si la solicitud tiene éxito, devuelve los datos obtenidos. Si hay un error, se maneja e imprime en la consola.
*/
export default class Model {
    async fetchData(tipo, valor) {
        try {
            //CAMBIAR LA IP A LA QUE SE NECESITE EN MI CASO ES ESTA PORQUE TRABAJE EN LOCAL EN MI CASA, SINO NO FUNCIONAAA
            const url = `http://192.168.1.195/DWES/Unidad6/ProyectoAPI/?${tipo}=${valor}`;
            const response = await axios.get(url);
            return response.data;
        } catch (error) {
            console.error("Error al obtener datos de la API:", error);
            throw error;
        }
    }
}
