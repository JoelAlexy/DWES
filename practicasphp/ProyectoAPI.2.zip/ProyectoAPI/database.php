<?php
class Database
{
    /**
     * Lee los datos de un archivo XML y los convierte en un arreglo de libros.
     *
     * @return array Un arreglo de libros, donde cada libro está representado como un array asociativo:
     */
    private function lecturaXML()
    {
        $xml = './xml/books.xml';
        $xmlData = simplexml_load_file($xml);
        $datos = [];

        foreach ($xmlData->book as $book) {
            $datos[] = [
                'id' => (string)$book['id'],
                'autor' => (string)$book->author,
                'titulo' => (string)$book->title,
                'genero' => (string)$book->genre,
                'precio' => (int)$book->price,
                'publicacion' => (int)$book->publish_date,
                'descripcion' => (string)$book->description
            ];
        }
        return $datos;
    }

    /**
     * Obtiene una lista de libros filtrada según los parámetros especificados.
     *
     * @param array $parametros Un array asociativo con los parámetros de filtrado opcionales.
     *                          Los parámetros pueden incluir cualquier campo del libro, como título, autor, etc.
     *                          Además, puede incluir el parámetro 'pagina' para paginar los resultados.
     * @return array Una matriz de libros que coinciden con los criterios de filtrado.
     */
    public function obtenerLibros($parametros = [])
    {
        $datos = $this->lecturaXML();
        if (!is_array($parametros)) {
            return $datos;
        } else {
            foreach ($parametros as $clave => $valor) {
                if ($clave !== 'pagina') {
                    $datos = array_filter($datos, function ($libro) use ($clave, $valor) {
                        return stripos($libro[$clave], $valor) !== false;
                    });
                } elseif (isset($parametros['pagina'])) {
                    $pagina = (int)$parametros['pagina'];
                    $tamanioPagina = 3; //Cambiar a lo que se quiera
                    $DatosPaginados = array_slice($datos, $pagina * $tamanioPagina, $tamanioPagina);
                    $datos = $DatosPaginados;
                }
            }

            return array_values($datos);
        }
    }
}
