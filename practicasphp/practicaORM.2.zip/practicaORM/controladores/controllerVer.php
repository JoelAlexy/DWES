<?php

if ($_GET["model"] == "Libro") {
    $all = $orm->findAll($_GET["model"]);
    include_once "vistas/verLibro.inc.php";
}
if ($_GET["model"] == "Pelicula") {
    $all = $orm->findAll($_GET["model"]);
    include_once "vistas/verPelicula.inc.php";
}

if ($_GET["model"] == "Disco") {
    $all = $orm->findAll($_GET["model"]);
    include_once "vistas/verDisco.inc.php";
}

