<?php
include_once "./ORM.php";
$orm = new ORM();
session_start();
// echo "VARIABLE GET: " . var_dump($_GET) . "<br>";
// echo var_dump($_SESSION);
include_once "vistas/cabecera.inc.php";

if (isset($_GET["ruta"]) && isset($_GET["model"])) {
    $ruta = $_GET["ruta"];
    $model = $_GET["model"];
    switch ($ruta) {
        case "ver":
            include_once "controllerVer.php";
            break;
        case "add":
            include_once "controllerCrear.php";
            break;
        case "modify":
            if (isset($_GET["id"])) {
                $id = $_GET["id"];
                include_once "controllerModificar.php";
            } else {
                include_once "vistas/error.inc.php";
            }
            break;
        case "error":
            include_once "vistas/error.inc.php";
            break;
        default:
            // Manejar rutas desconocidas
            include_once "vistas/error.inc.php";
            break;
    }
} else {
    //include_once "vistas/error.inc.php";
    header("Location:ver/Libro");

    //https://localhost/DWES/Unidad6/practicaORM/ver/Libro
}
include_once "vistas/pie.inc.php";
