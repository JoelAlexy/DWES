<?php
if ($_GET["model"] == "Libro")
    include_once "modelos/Libro.php";
if ($_GET["model"] == "Disco")
    include_once "modelos/Disco.php";
if ($_GET["model"] == "Pelicula")
    include_once "modelos/Pelicula.php";
$id = $_GET["id"];

if (isset($_POST["modifyLibro"])) {
    if (isset($_POST["isbn"]) && !empty($_POST["isbn"]) && isset($_POST["genero"])  && isset($_POST["extension"]) && isset($_POST["publicacion"]) && isset($_POST["anio"])  && isset($_POST["autor"]) && isset($_POST["titulo"])) {
        //Saneamiento de las variables recogidas
        $isbn = htmlspecialchars($_POST["isbn"], ENT_QUOTES, 'UTF-8');
        $genero = htmlspecialchars($_POST["genero"], ENT_QUOTES, 'UTF-8');
        $extension = htmlspecialchars($_POST["extension"], ENT_QUOTES, 'UTF-8');
        $publicacion = htmlspecialchars($_POST["publicacion"], ENT_QUOTES, 'UTF-8');
        $anio = htmlspecialchars($_POST["anio"], ENT_QUOTES, 'UTF-8');
        $autor = htmlspecialchars($_POST["autor"], ENT_QUOTES, 'UTF-8');
        $titulo = htmlspecialchars($_POST["titulo"], ENT_QUOTES, 'UTF-8');

        $libro = new Libro();
        $libro->setId($id);
        $libro->setIsbn($isbn);
        $libro->setGenero($genero);
        $libro->setExtension($extension);
        $libro->setPublicacion($publicacion);
        $libro->setAnio($anio);
        $libro->setAutor($autor);
        $libro->setTitulo($titulo);

        $orm->flush($libro);
        $_SESSION['mensaje'] = "Libro modificado correctamente";
        header("Location: ../practicaORM/ver/Libro");
    } else {
        $errRegistro = true;
    }
}

if (isset($_POST["modifyPelicula"])) {
    if (isset($_POST["isan"]) && !empty($_POST["isan"]) && isset($_POST["genero"])  && isset($_POST["duracion"]) && isset($_POST["publicacion"]) && isset($_POST["anio"])  && isset($_POST["reparto"]) && isset($_POST["director"]) && isset($_POST["titulo"])) {
        //Saneamiento de las variables recogidas
        $isan = htmlspecialchars($_POST["isan"], ENT_QUOTES, 'UTF-8');
        $genero = htmlspecialchars($_POST["genero"], ENT_QUOTES, 'UTF-8');
        $duracion = htmlspecialchars($_POST["duracion"], ENT_QUOTES, 'UTF-8');
        $publicacion = htmlspecialchars($_POST["publicacion"], ENT_QUOTES, 'UTF-8');
        $anio = htmlspecialchars($_POST["anio"], ENT_QUOTES, 'UTF-8');
        $reparto = htmlspecialchars($_POST["reparto"], ENT_QUOTES, 'UTF-8');
        $director = htmlspecialchars($_POST["director"], ENT_QUOTES, 'UTF-8');
        $titulo = htmlspecialchars($_POST["titulo"], ENT_QUOTES, 'UTF-8');

        $pelicula = new Pelicula();
        $pelicula->setId($id);
        $pelicula->setIsan($isan);
        $pelicula->setGenero($genero);
        $pelicula->setDuracion($duracion);
        $pelicula->setPublicacion($publicacion);
        $pelicula->setAnio($anio);
        $pelicula->setReparto($reparto);
        $pelicula->setDirector($director);
        $pelicula->setTitulo($titulo);

        $orm->flush($pelicula);
        $_SESSION['mensaje'] = "Pelicula modificada correctamente";
        header("Location: ../practicaORM/ver/Pelicula");
    } else {
        $errRegistro = true;
    }
}

if (isset($_POST["modifyDisco"])) {
    if (isset($_POST["iswc"]) && !empty($_POST["iswc"]) && isset($_POST["genero"])  && isset($_POST["duracion"]) && isset($_POST["publicacion"]) && isset($_POST["anio"])  && isset($_POST["grupo"]) && isset($_POST["titulo"])) {
        //Saneamiento de las variables recogidas
        $iswc = htmlspecialchars($_POST["iswc"], ENT_QUOTES, 'UTF-8');
        $genero = htmlspecialchars($_POST["genero"], ENT_QUOTES, 'UTF-8');
        $duracion = htmlspecialchars($_POST["duracion"], ENT_QUOTES, 'UTF-8');
        $publicacion = htmlspecialchars($_POST["publicacion"], ENT_QUOTES, 'UTF-8');
        $anio = htmlspecialchars($_POST["anio"], ENT_QUOTES, 'UTF-8');
        $grupo = htmlspecialchars($_POST["grupo"], ENT_QUOTES, 'UTF-8');
        $titulo = htmlspecialchars($_POST["titulo"], ENT_QUOTES, 'UTF-8');

        $disco = new Disco();
        $disco->setId($id);
        $disco->setIswc($iswc);
        $disco->setGenero($genero);
        $disco->setDuracion($duracion);
        $disco->setPublicacion($publicacion);
        $disco->setAnio($anio);
        $disco->setGrupo($grupo);
        $disco->setTitulo($titulo);

        $orm->flush($disco);
        $_SESSION['mensaje'] = "Disco modificado correctamente";
        header("Location: ../../ver/Disco");
    } else {
        $errRegistro = true;
    }
}

if ($_GET["model"] == "Libro") {

    $consulta = $orm->find($_GET["model"], $id);
    include_once "vistas/modificarLibro.inc.php";
}
if ($_GET["model"] == "Disco") {

    $consulta = $orm->find($_GET["model"], $id);
    include_once "vistas/modificarDisco.inc.php";
}
if ($_GET["model"] == "Pelicula") {

    $consulta = $orm->find($_GET["model"], $id);
    include_once "vistas/modificarPelicula.inc.php";
}
