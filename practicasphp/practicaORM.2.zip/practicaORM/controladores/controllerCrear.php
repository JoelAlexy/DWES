<?php

if (isset($_POST["addLibro"])) {
    include "modelos/Libro.php";
    if (isset($_POST["isbn"]) && !empty($_POST["isbn"]) && isset($_POST["genero"])  && isset($_POST["extension"]) && isset($_POST["publicacion"]) && isset($_POST["anio"])  && isset($_POST["autor"]) && isset($_POST["titulo"])) {
    //Saneamiento de las variables recogidas
    $isbn = htmlspecialchars($_POST["isbn"], ENT_QUOTES, 'UTF-8');
    $genero = htmlspecialchars($_POST["genero"], ENT_QUOTES, 'UTF-8');
    $extension = htmlspecialchars($_POST["extension"], ENT_QUOTES, 'UTF-8');
    $publicacion = htmlspecialchars($_POST["publicacion"], ENT_QUOTES, 'UTF-8');
    $anio = htmlspecialchars($_POST["anio"], ENT_QUOTES, 'UTF-8');
    $autor = htmlspecialchars($_POST["autor"], ENT_QUOTES, 'UTF-8');
    $titulo = htmlspecialchars($_POST["titulo"], ENT_QUOTES, 'UTF-8');

    $libro = new Libro();
    $libro->setIsbn($isbn);
    $libro->setGenero($genero);
    $libro->setExtension($extension);
    $libro->setPublicacion($publicacion);
    $libro->setAnio($anio);
    $libro->setAutor($autor);
    $libro->setTitulo($titulo);

    $orm->persist($libro);
    $_SESSION['mensaje'] = "Libro insertado correctamente";
    header("Location: ../../practicaORM/ver/Libro");
} else {
    $errRegistro = true;
}
}

if (isset($_POST["addPelicula"])) {
    include "modelos/Pelicula.php";
    if (isset($_POST["isan"]) && !empty($_POST["isan"]) && isset($_POST["genero"])  && isset($_POST["duracion"]) && isset($_POST["publicacion"]) && isset($_POST["anio"])  && isset($_POST["reparto"]) && isset($_POST["director"]) && isset($_POST["titulo"])) {
    //Saneamiento de las variables recogidas
    $isan = htmlspecialchars($_POST["isan"], ENT_QUOTES, 'UTF-8');
    $genero = htmlspecialchars($_POST["genero"], ENT_QUOTES, 'UTF-8');
    $duracion = htmlspecialchars($_POST["duracion"], ENT_QUOTES, 'UTF-8');
    $publicacion = htmlspecialchars($_POST["publicacion"], ENT_QUOTES, 'UTF-8');
    $anio = htmlspecialchars($_POST["anio"], ENT_QUOTES, 'UTF-8');
    $reparto = htmlspecialchars($_POST["reparto"], ENT_QUOTES, 'UTF-8');
    $director = htmlspecialchars($_POST["director"], ENT_QUOTES, 'UTF-8');
    $titulo = htmlspecialchars($_POST["titulo"], ENT_QUOTES, 'UTF-8');

    $pelicula = new Pelicula();
    $pelicula->setIsan($isan);
    $pelicula->setGenero($genero);
    $pelicula->setDuracion($duracion);
    $pelicula->setPublicacion($publicacion);
    $pelicula->setAnio($anio);
    $pelicula->setReparto($reparto);
    $pelicula->setDirector($director);
    $pelicula->setTitulo($titulo);

    $_SESSION['mensaje'] = "Pelicula insertada correctamente";
    $orm->persist($pelicula);

    header("Location: ../../practicaORM/ver/Pelicula");
} else {
    $errRegistro = true;
}
}

if (isset($_POST["addDisco"])) {
    include "modelos/Disco.php";
    if (isset($_POST["iswc"]) && !empty($_POST["iswc"]) && isset($_POST["genero"])  && isset($_POST["duracion"]) && isset($_POST["publicacion"]) && isset($_POST["anio"])  && isset($_POST["grupo"]) && isset($_POST["titulo"])) {
    //Saneamiento de las variables recogidas
    $iswc = htmlspecialchars($_POST["iswc"], ENT_QUOTES, 'UTF-8');
    $genero = htmlspecialchars($_POST["genero"], ENT_QUOTES, 'UTF-8');
    $duracion = htmlspecialchars($_POST["duracion"], ENT_QUOTES, 'UTF-8');
    $publicacion = htmlspecialchars($_POST["publicacion"], ENT_QUOTES, 'UTF-8');
    $anio = htmlspecialchars($_POST["anio"], ENT_QUOTES, 'UTF-8');
    $grupo = htmlspecialchars($_POST["grupo"], ENT_QUOTES, 'UTF-8');
    $titulo = htmlspecialchars($_POST["titulo"], ENT_QUOTES, 'UTF-8');

    $disco = new Disco();
    $disco->setIswc($iswc);
    $disco->setGenero($genero);
    $disco->setDuracion($duracion);
    $disco->setPublicacion($publicacion);
    $disco->setAnio($anio);
    $disco->setGrupo($grupo);
    $disco->setTitulo($titulo);

    $orm->persist($disco);
    $_SESSION['mensaje'] = "Disco insertada correctamente";
    header("Location: ../../practicaORM/ver/Disco");
} else {
    $errRegistro = true;
}
}

if ($_GET["model"] == "Libro")
    include_once "vistas/crearLibro.inc.php";
if ($_GET["model"] == "Disco")
    include_once "vistas/crearDisco.inc.php";
if ($_GET["model"] == "Pelicula")
    include_once "vistas/crearPelicula.inc.php";
