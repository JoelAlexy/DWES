<?php
class ORM
{
    //Atributos de conexión a base de datos
    private static $host = "localhost";
    private static $user = "alumno";
    private static $password = "1234";
    private static $database = "bibliotecaORM";

    //Metodos
    public static function connectDB()
    {
        try {
            $connection = new PDO("mysql:host=" . self::$host . ";dbname=" . self::$database . ";charset=utf8", self::$user, self::$password);
        } catch (PDOException $e) {
            echo "No se ha podido establecer conexión con el servidor de bases de datos.<br>";
            die("Error: " . $e->getMessage());
        }
        return $connection;
    }
    /**
     * Creamos en la base de datos con las propiedades del objeto
     * Usamos PDO y sentencias preparadas
     */
    public function persist(&$object)
    {
        try {
            $id = 0; //aux para obtener el siguiente id
            $dbConn = self::connectDB();
            $dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $dbConn->beginTransaction();
            //Obtenemos el siguiente id de la tabla
            $sentencia = $dbConn->prepare("SELECT `AUTO_INCREMENT` FROM  INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '" . self::$database . "' AND TABLE_NAME = '" . get_class($object) . "';");
            if ($sentencia->execute()) {
                while ($fila = $sentencia->fetch()) {
                    $id = $fila;
                }
            }
            $dbConn->commit();
        } catch (Exception $e) {
            $dbConn->rollBack();
            echo "Fallo: " . $e->getMessage();
        }
        //Asignamos el id de base de datos al objeto
        $object->setId($id["AUTO_INCREMENT"]);
        try {
            $dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $dbConn->beginTransaction();
            //Insertamos el objeto en la base de datos
            if (get_class($object) == "Disco") {
                $sentencia = $dbConn->prepare("INSERT INTO " . get_class($object) . " (genero,anio,titulo,publicacion,duracion,iswc,grupo) VALUES (?,?,?,?,?,?,?)");

                $sentencia->bindParam(5, $duracion);
                $sentencia->bindParam(6, $iswc);
                $sentencia->bindParam(7, $grupo);

                $duracion = $object->getDuracion();
                $iswc = $object->getIswc();
                $grupo = $object->getGrupo();
            }
            if (get_class($object) == "Libro") {
                $sentencia = $dbConn->prepare("INSERT INTO " . get_class($object) . " (genero,anio,titulo,publicacion,isbn,extension,autor) VALUES (?,?,?,?,?,?,?)");
                $sentencia->bindParam(5, $isbn);
                $sentencia->bindParam(6, $extension);
                $sentencia->bindParam(7, $autor);

                $isbn = $object->getIsbn();
                $extension = $object->getExtension();
                $autor = $object->getAutor();
            }
            if (get_class($object) == "Pelicula") {
                $sentencia = $dbConn->prepare("INSERT INTO " . get_class($object) . " (genero,anio,titulo,publicacion,duracion,isan,reparto,director) VALUES (?,?,?,?,?,?,?,?)");
                $sentencia->bindParam(5, $duracion);
                $sentencia->bindParam(6, $isan);
                $sentencia->bindParam(7, $reparto);
                $sentencia->bindParam(8, $director);

                $duracion = $object->getDuracion();
                $isan = $object->getIsan();
                $reparto = $object->getReparto();
                $director = $object->getDirector();
            }
            $sentencia->bindParam(1, $genero);
            $sentencia->bindParam(2, $anio);
            $sentencia->bindParam(3, $titulo);
            $sentencia->bindParam(4, $publicacion);

            $genero = $object->getGenero();
            $anio = $object->getAnio();
            $titulo = $object->getTitulo();
            $publicacion = $object->getPublicacion();

            $sentencia->execute();
            $dbConn->commit();
        } catch (Exception $e) {
            $dbConn->rollBack();
            echo "Fallo: " . $e->getMessage();
        }
        $dbConn = null;
    }
    /**
     * Actualizamos la base de datos con las propiedades del objeto
     * Usamos PDO y sentencias preparadas
     */
    public function flush(&$object)
    {

        try {
            $dbConn = self::connectDB();
            $dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $dbConn->beginTransaction();
            //Actualizaremos todos los atributos del objeto
            if (get_class($object) == "Disco") {
                $sentencia = $dbConn->prepare("UPDATE " . get_class($object) . " SET genero = ? ,  anio = ? ,  titulo = ? ,  publicacion = ? ,  duracion = ? ,   iswc = ? ,   grupo = ? WHERE id = ?");
                $sentencia->bindParam(5, $duracion);
                $sentencia->bindParam(6, $iswc);
                $sentencia->bindParam(7, $grupo);
                $sentencia->bindParam(8, $id);

                $duracion = $object->getDuracion();
                $iswc = $object->getIswc();
                $grupo = $object->getGrupo();
            }
            if (get_class($object) == "Libro") {
                $sentencia = $dbConn->prepare("UPDATE " . get_class($object) . " SET genero = ? ,  anio = ? ,  titulo = ? ,  publicacion = ? ,   isbn = ? ,   extension = ?  , autor = ? WHERE id = ?");
                $sentencia->bindParam(5, $isbn);
                $sentencia->bindParam(6, $extension);
                $sentencia->bindParam(7, $autor);
                $sentencia->bindParam(8, $id);

                $isbn = $object->getIsbn();
                $extension = $object->getExtension();
                $autor = $object->getAutor();
                
            }
            if (get_class($object) == "Pelicula") {
                $sentencia = $dbConn->prepare("UPDATE " . get_class($object) . " SET genero = ? ,  anio = ? ,  titulo = ? ,  publicacion = ? ,  duracion = ? ,   isan = ? ,   reparto = ? , director = ? WHERE id = ?");
                $sentencia->bindParam(5, $duracion);
                $sentencia->bindParam(6, $isan);
                $sentencia->bindParam(7, $reparto);
                $sentencia->bindParam(8, $director);
                $sentencia->bindParam(9, $id);

                $duracion = $object->getDuracion();
                $isan = $object->getIsan();
                $reparto = $object->getReparto();
                $director = $object->getDirector();
            }
            $sentencia->bindParam(1, $genero);
            $sentencia->bindParam(2, $anio);
            $sentencia->bindParam(3, $titulo);
            $sentencia->bindParam(4, $publicacion);
            
            $genero = $object->getGenero();
            $anio = $object->getAnio();
            $titulo = $object->getTitulo();
            $publicacion = $object->getPublicacion();
            $id = $object->getId();
            $sentencia->execute();
            $dbConn->commit();
        } catch (Exception $e) {
            $dbConn->rollBack();
            echo "Fallo: " . $e->getMessage();
        }
        $dbConn = null;
    }

    /**
     * Obtenemos todas las tuplas de base de datos en un array de objetos.
     * Usamos PDO y sentencias preparadas
     */
    public function findAll($table)
    {
        try {
            $dbConn = self::connectDB();
            $dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $dbConn->beginTransaction();

            $sentencia = $dbConn->prepare("SELECT * FROM " . $table);
            $sentencia->execute();
            $arrResult = $sentencia->fetchAll(PDO::FETCH_ASSOC);

            $dbConn->commit();
        } catch (Exception $e) {
            $dbConn->rollBack();
            echo "Fallo: " . $e->getMessage();
        }
        $dbConn = null;

        return $arrResult;
    }
    /**
     * Obtenemos un objeto de la tupla seleccionada en 
     * base de datos a partir del id
     * Usamos PDO y sentencias preparadas
     */
    public function find($table, $id)
    {
        try {
            $arrResult = array();
            $dbConn = self::connectDB();
            $dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $dbConn->beginTransaction();
            $sentencia = $dbConn->prepare("SELECT * FROM " . $table . " WHERE id = ?");
            if ($sentencia->execute(array($id))) {
                while ($fila = $sentencia->fetch()) {
                    $arrResult = $fila;
                }
            }
            $dbConn->commit();
        } catch (Exception $e) {
            $dbConn->rollBack();
            echo "Fallo: " . $e->getMessage();
        }
        $dbConn = null;


        if ($arrResult != null) {
            $object = new $table();
            $object->setId($arrResult[0]);
            $object->setGenero($arrResult[2]);
            $object->setPublicacion($arrResult[4]);
            $object->setAnio($arrResult[5]);
            if ($table == "Libro") {
                $object->setIsbn($arrResult[1]);
                $object->setExtension($arrResult[3]);
                $object->setAutor($arrResult[6]);
                $object->setTitulo($arrResult[7]);
            }
            if ($table == "Disco") {
                $object->setIswc($arrResult[1]);
                $object->setDuracion($arrResult[3]);
                $object->setGrupo($arrResult[6]);
                $object->setTitulo($arrResult[7]);
            }
            if ($table == "Pelicula") {
                $object->setIsan($arrResult[1]);
                $object->setDuracion($arrResult[3]);
                $object->setReparto($arrResult[6]);
                $object->setDirector($arrResult[7]);
                $object->setTitulo($arrResult[8]);
            }
        } else $object = null;

        return $object;
    }
}
