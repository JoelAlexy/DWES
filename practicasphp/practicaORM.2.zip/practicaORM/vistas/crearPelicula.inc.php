<?php if (isset($errRegistro) && $errRegistro == true) { ?>
	<div class="alert alert-danger" role="alert">
		Datos obligatorios mal insertados
	</div>
<?php } ?>
<section>
	<br>
	<div class="container">
		<form action="" method="post">
			<h2 class="h4">Registro Pelicula</h2>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="isan" name="isan" placeholder="isan" required="required">
				<label for="floatingInput">ISAN*</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="genero" name="genero" placeholder="genero">
				<label for="floatingInput">Genero</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="duracion" name="duracion" placeholder="Duracion">
				<label for="floatingInput">Duracion</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="publicacion" name="publicacion" placeholder="publicacion">
				<label for="floatingInput">Publicacion</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="anio" name="anio" placeholder="año">
				<label for="floatingInput">Año</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="reparto" name="reparto" placeholder="reparto">
				<label for="floatingInput">Reparto</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="director" name="director" placeholder="director">
				<label for="floatingInput">Director</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="titulo" name="titulo" placeholder="titulo">
				<label for="floatingInput">Titulo</label>
			</div>
			<div class="d-flex justify-content-center">
				<input class="btn btn-primary" type="submit" id="addPelicula" name="addPelicula" value="Añadir Pelicula">
				<a class="btn btn-danger" href="../ver/Pelicula">Volver</a>
			</div>


		</form>
	</div>
</section>