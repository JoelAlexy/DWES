<?php if (isset($errRegistro) && $errRegistro == true) { ?>
    <div class="alert alert-danger" role="alert">
        Datos obligatorios mal insertados
    </div>
<?php } ?>
<section>
    <br>

    <div class="container">
        <form action="<?php echo $_SERVER["PHP_SELF"] ?>?ruta=modify&model=Libro&id=<?php echo $consulta->getId() ?>" method="post">
            <h2 class="h4">Registro</h2>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="id" name="id" placeholder="id"  value="<?php echo $consulta->getId() ?>" disabled>
                <label for="floatingInput">ID</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="isbn" name="isbn" placeholder="isbn"  value="<?php echo $consulta->getIsbn() ?>">
                <label for="floatingInput">ISBN*</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="genero" name="genero" placeholder="genero" value="<?php echo $consulta->getGenero() ?>">
                <label for="floatingInput">Genero</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="extension" name="extension" placeholder="extension" value="<?php echo $consulta->getExtension() ?>">
                <label for="floatingInput">Extension</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="publicacion" name="publicacion" placeholder="publicacion" value="<?php echo $consulta->getPublicacion() ?>">
                <label for="floatingInput">Publicacion</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="anio" name="anio" placeholder="año" value="<?php echo $consulta->getAnio() ?>">
                <label for="floatingInput">Año</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="autor" name="autor" placeholder="autor" value="<?php echo $consulta->getAutor() ?>">
                <label for="floatingInput">Autor</label>
            </div>
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="titulo" name="titulo" placeholder="titulo" value="<?php echo $consulta->getTitulo() ?>">
                <label for="floatingInput">Titulo</label>
            </div>
            <div class="d-flex justify-content-center">
                <input class="btn btn-primary" type="submit" id="modifyLibro" name="modifyLibro" value="Modificar Libro">
                <a class="btn btn-danger" href="../../ver/Libro">Volver</a>
                
            </div>
            
        </form>
        

    </div>
</section>