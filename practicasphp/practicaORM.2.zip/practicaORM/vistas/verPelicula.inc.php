<?php
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    // Luego, puedes mostrar el mensaje como una variable JavaScript
    echo "<script> var mensaje = '$mensaje'; </script>";
    // Elimina el mensaje de la sesión para que no se muestre nuevamente
    unset($_SESSION['mensaje']);
}


?>
<br>
<div class="row">
    <a class="btn btn-success" href="../add/Pelicula">Añadir Pelicula</a>
    <?php
    if (count($all) > 0) {
        foreach ($all as $pelicula) {
    ?>
            <div class="col-md-3 mb-4">
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $pelicula['titulo'] ?></h5>
                        <h6 class="card-subtitle mb-2 text-body-secondary"><?php echo $pelicula['director'] ?></h6>
                        <p class="card-text">ISAN <?=$pelicula['isan'] ?></p>
                        <p class="card-text">Genero <?=$pelicula['genero'] ?></p>
                        <p class="card-text">Duracion <?= $pelicula['duracion'] ?></p>
                        <p class="card-text">Publicacion <?= $pelicula['publicacion'] ?></p>
                        <p class="card-text">Año <?= $pelicula['anio'] ?></p>
                        <p class="card-text">Reparto <?=$pelicula['reparto'] ?></p>
                        <p class="card-text">Director <?= $pelicula['director'] ?></p>

                        <a class="btn btn-warning " href="../modify/Pelicula/<?=$pelicula["id"]?>">Modificar</a>
                    </div>
                </div>
            </div>
        <?php
        }
    } else { ?>
        <h5 class="card-title">No hay datos a mostrar</h5>
    <?php } ?>
</div>
<script>
    // JavaScript para mostrar el mensaje después de la redirección
    if (typeof mensaje !== 'undefined') {
        alert(mensaje);
    }
</script>