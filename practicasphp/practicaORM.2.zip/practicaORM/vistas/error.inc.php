<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center mt-5">
                <h1 class="display-4">¡Error!</h1>
                <p class="lead">Lo sentimos, ha ocurrido un error en la página.</p>
                <p>Por favor, vuelva a intentarlo más tarde.</p>
                <a class="btn btn-warning" href="../practicaORM/ver/Libro">Volver</a>
            </div>
        </div>
    </div>
</div>