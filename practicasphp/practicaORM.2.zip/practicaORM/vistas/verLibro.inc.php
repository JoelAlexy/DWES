<?php
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    // Luego, puedes mostrar el mensaje como una variable JavaScript
    echo "<script> var mensaje = '$mensaje'; </script>";
    // Elimina el mensaje de la sesión para que no se muestre nuevamente
    unset($_SESSION['mensaje']);
}


?>
<br>
<div class="row">

    <a class="btn btn-success" href="../add/Libro">Añadir Libros</a>
    <?php
    if (count($all) > 0) {
        foreach ($all as $libro) {
    ?>
            <div class="col-md-3 mb-4">
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title"><?= $libro['titulo'] ?></h5>
                        <h6 class="card-subtitle mb-2 text-body-secondary"><?= $libro['autor'] ?></h6>
                        <p class="card-text">ISBN <?=$libro['isbn'] ?></p>
                        <p class="card-text">Genero <?=$libro['genero'] ?></p>
                        <p class="card-text">Extension <?=$libro['extension'] ?></p>
                        <p class="card-text">Año <?=$libro['anio'] ?></p>
                        <p class="card-text">Publicacion <?= $libro['publicacion'] ?></p>
                        <a class="btn btn-warning " href="../modify/Libro/<?= $libro["id"]; ?>">Modificar</a>
                    </div>
                </div>
            </div>
        <?php
        }
    } else { ?>
        <h5 class="card-title">No hay datos a mostrar</h5>
    <?php } ?>
</div>
<script>
    // JavaScript para mostrar el mensaje después de la redirección
    if (typeof mensaje !== 'undefined') {
        alert(mensaje);
    }
</script>