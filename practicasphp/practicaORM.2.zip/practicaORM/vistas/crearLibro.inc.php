<?php if (isset($errRegistro) && $errRegistro == true) { ?>
	<div class="alert alert-danger" role="alert">
		Datos obligatorios mal insertados
	</div>
<?php } ?>
<section>
	<br>
	<div class="container">
		<form action="" method="post">
			<h2 class="h4">Registro Libro</h2>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="isbn" name="isbn" placeholder="isbn" required="required">
				<label for="floatingInput">ISBN*</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="genero" name="genero" placeholder="genero">
				<label for="floatingInput">Genero</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="extension" name="extension" placeholder="extension">
				<label for="floatingInput">Extension</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="publicacion" name="publicacion" placeholder="publicacion">
				<label for="floatingInput">Publicacion</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="anio" name="anio" placeholder="año">
				<label for="floatingInput">Año</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="autor" name="autor" placeholder="autor">
				<label for="floatingInput">Autor</label>
			</div>
			<div class="form-floating mb-3">
				<input type="text" class="form-control" id="titulo" name="titulo" placeholder="titulo">
				<label for="floatingInput">Titulo</label>
			</div>
			<div class="d-flex justify-content-center">
				<input class="btn btn-primary" type="submit" id="addLibro" name="addLibro" value="Añadir Libro">
				<a class="btn btn-danger" href="../ver/Libro">Volver</a>
			</div>
			

		</form>
	</div>
</section>