  <footer class="bg-dark text-light text-center >
      <div class=" container">
      <p>&copy; 2023 Mi Sitio Web. Todos los derechos reservados.</p>
      </div>
  </footer>

  </div>

  </body>

  </html>