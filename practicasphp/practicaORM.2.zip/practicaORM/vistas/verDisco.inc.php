<?php
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    // Luego, puedes mostrar el mensaje como una variable JavaScript
    echo "<script> var mensaje = '$mensaje'; </script>";
    // Elimina el mensaje de la sesión para que no se muestre nuevamente
    unset($_SESSION['mensaje']);
}
?>
<br>
<div class="row">
    <a class="btn btn-success" href="../add/Disco">Añadir Discos</a>
    <?php
    if (count($all) > 0) {
        foreach ($all as $disco) {
    ?>
            <div class="col-md-3 mb-4">
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $disco['titulo'] ?></h5>
                        <h6 class="card-subtitle mb-2 text-body-secondary"><?php echo $disco['grupo'] ?></h6>
                        <p class="card-text">ISWC <?= $disco['iswc'] ?></p>
                        <p class="card-text">Genero <?= $disco['genero'] ?></p>
                        <p class="card-text">Extension <?= $disco['duracion'] ?></p>
                        <p class="card-text">Año <?= $disco['anio'] ?></p>
                        <p class="card-text">Publicacion <?=$disco['publicacion'] ?></p>
                        <a class="btn btn-warning " href="../modify/Disco/<?=$disco["id"]?>">Modificar</a>
                    
                    </div>
                </div>
            </div>
        <?php
        }
    } else { ?>
        <h5 class="card-title">No hay datos a mostrar</h5>
    <?php } ?>
</div>
<script>
    // JavaScript para mostrar el mensaje después de la redirección
    if (typeof mensaje !== 'undefined') {
        alert(mensaje);
    }
</script>