<?php include "Principal.php";
class Disco extends Principal
{
    //Atributos
    private $iswc;
    private $grupo;
    private $duracion;
    //Metodo constructor
    public function __construct($genero = null, $anio = null, $titulo = null, $publicacion = null, $duracion = null, $iswc = null, $grupo = null)
    {
        parent::__construct($genero, $anio, $titulo, $publicacion);
        $this->iswc = $iswc;
        $this->grupo = $grupo;
        $this->duracion = $duracion;
    }
    //Metodos Getter/Setter

    public function getIswc()
    {
        return $this->iswc;
    }

    public function setIswc($iswc)
    {
        return $this->iswc = $iswc;
    }
    public function getGrupo()
    {
        return $this->grupo;
    }

    public function setGrupo($grupo)
    {
        return $this->grupo = $grupo;
    }
    public function getDuracion()
	{
		return $this->duracion;
	}

	public function setDuracion($duracion)
	{
		$this->duracion = $duracion;
	}
    //Metodos

}