<?php
include "Principal.php";
class Pelicula extends Principal
{
    //Atributos
    private $isan;
    private $reparto;
    private $director;

    private $duracion;
    //Metodo constructor
    public function __construct($genero = null, $anio = null, $titulo = null, $publicacion = null, $duracion = null, $isan = null, $reparto = null, $director = null)
    {
        parent::__construct($genero, $anio, $titulo, $publicacion);
        $this->isan = $isan;
        $this->reparto = $reparto;
        $this->director = $director;
        $this->duracion = $duracion;
    }
    //Metodos Getter/Setter

    public function getIsan()
    {
        return $this->isan;
    }

    public function setIsan($isan)
    {
        return $this->isan = $isan;
    }
    public function getReparto()
    {
        return $this->reparto;
    }

    public function setReparto($reparto)
    {
        return $this->reparto = $reparto;
    }

    public function getDirector()
    {
        return $this->director;
    }

    public function setDirector($director)
    {
        return $this->director = $director;
    }
    	public function getDuracion()
	{
		return $this->duracion;
	}

	public function setDuracion($duracion)
	{
		$this->duracion = $duracion;
	}
    //Metodos


}
