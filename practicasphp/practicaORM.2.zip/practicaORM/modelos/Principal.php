
<?php
abstract class Principal
{
	//Atributos
	private $id;
	private $genero;
	private $anio;
	private $titulo;
	private $publicacion;

	//Metodo constructor
	public function __construct($id,$genero = null, $anio = null, $titulo = null, $publicacion = null)
	{
		$this->id = $id;
		$this->genero = $genero;
		$this->anio = $anio;
		$this->titulo = $titulo;
		$this->publicacion = $publicacion;
	}
	public function getId()
	{
		return $this->id;
	}
	
	public function setId($id)
	{
		$this->id = $id;
	}
	public function getGenero()
	{
		return $this->genero;
	}

	public function setGenero($genero)
	{
		return $this->genero = $genero;
	}

	public function getAnio()
	{
		return $this->anio;
	}

	public function setAnio($anio)
	{
		$this->anio = $anio;
	}

	public function getTitulo()
	{
		return $this->titulo;
	}

	public  function setTitulo($titulo)
	{
		return $this->titulo = $titulo;
	}

	public function getPublicacion()
	{
		return $this->publicacion;
	}

	public function setPublicacion($publicacion)
	{
		$this->publicacion = $publicacion;
	}
}

?>