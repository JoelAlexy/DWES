<?php 
include "Principal.php";

class Libro extends Principal
{
    //Atributos
    private $isbn;
    private $extension;
    private $autor;
    //Metodo constructor
    public function __construct($genero = null, $anio = null, $titulo = null, $publicacion = null, $duracion = null, $isbn = null, $extension = null, $autor = null)
    {
        parent::__construct($genero, $anio, $titulo, $publicacion, $duracion);
        $this->isbn = $isbn;
        $this->extension = $extension;
        $this->autor = $autor;
    }
    //Metodos Getter/Setter
    public function getIsbn()
    {
        return $this->isbn;
    }

    public function setIsbn($isbn)
    {
        return $this->isbn = $isbn;
    }
    public function getExtension()
    {
        return $this->extension;
    }

    public function setExtension($extension)
    {
        return $this->extension = $extension;
    }

    public function getAutor()
    {
        return $this->autor;
    }

    public function setAutor($autor)
    {
        return $this->autor = $autor;
    }
    //Metodos

}
