/*
Aquí se define una clase View que maneja la presentación de los datos en la interfaz de usuario.
Al instanciar un objeto View, se establece un contenedor donde se mostrarán los datos.
Define un método displayData que toma los datos obtenidos del modelo y los muestra en el contenedor.
Si no hay resultados, muestra un mensaje indicando que no hay resultados.
Define un método displayError que maneja la presentación de errores en la interfaz de usuario, mostrando un mensaje de error en la consola.
*/
export default class View {
    constructor() {
        this.container = document.getElementById("app");
    }

    displayData(data) {
        // Limpiar el contenedor antes de mostrar los nuevos datos
        this.container.innerHTML = "";

        // Iterar sobre los usuarios y crear elementos para mostrar cada uno
        if (data.libros.length > 0) {
            data.libros.forEach((libro) => {
                const element = document.createElement("div");
                element.className = "estiloDiv";
                element.innerHTML = ` <p>ID: ${libro.id} </p> 
                                        <p>Autor: ${libro.autor}</p>
                                        <p>Título: ${libro.titulo}</p>
                                        <p>Genero: ${libro.genero}</p>
                                        <p>Descripcion: ${libro.descripcion}</p>`;
                this.container.appendChild(element);
            });
        } else {
            const element = document.createElement("div");
            element.innerHTML=`No hay resultados`
            element.style.color="red"
            element.style.fontSize="50px"
            this.container.appendChild(element);
        }
    }
    displayError(error) {
        // Mostrar mensaje de error en la interfaz de usuario
        console.error("Error al obtener datos:", error);
    }
}
